// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_POINT_SET_TESTER_H
#define __LIT_POINT_SET_TESTER_H

#include "litTesterBase.h"

namespace lit {

    /*! @brief Tester that compares two point sets (itk::PointSet)
    * @ingroup Tester*/
    template<class TPointSet>
    class PointSetTester: public TesterBase
    {
    public:
      typedef PointSetTester<TPointSet> Self;
      typedef TesterBase Superclass;
      typedef TPointSet PointSetType;
      typedef typename PointSetType::Pointer PointSetPointer;
      typedef typename PointSetType::ConstPointer PointSetConstPointer;
      typedef typename PointSetType::PointType PointType;

      virtual StringType getTestDescription(void) const;
      virtual StringType getTestName(void) const;

      void setExpectedPointSet(const PointSetType* pPointSet);
      void setActualPointSet(const PointSetType* pPointSet);
      void setCheckThreshold(double checkThreshold);

      const PointSetType* getExpectedPointSet() const;
      const PointSetType* getActualPointSet() const;
      double getCheckThreshold() const;

      PointSetTester();
      virtual ~PointSetTester();

    protected:
      PointSetConstPointer _spExpectedPointSet;
      PointSetConstPointer _spActualPointSet;
      double _checkThreshold;
      mutable unsigned long _errorPointCount;
      mutable typename PointType::RealType _maxError;
      mutable PointType _maxErrorPointAct;
      mutable PointType _maxErrorPointExp;

      /*! performes the test and checks the results.
      * @result Indicates if the test was successfull (true) or if it failed (false)
      */
      virtual bool doCheck(void) const;

      /*! Function will be called be check() if test was succesfull.
      * Implement to realize special tester behaviour.
      */
      virtual void handleSuccess(void) const;

      /*! Function will be called be check() if test was a failure.
      * Implement to realize special tester behaviour.
      */
      virtual void handleFailure(void) const;

    private:
      PointSetTester(Self& source); //purposely not implemented
      void operator=(const Self&); //purposely not implemented
    };

}

#ifndef Litmus_MANUAL_TPP
# include "litPointSetTester.tpp"
#endif

#endif
