// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTestLocation.h"

namespace lit {

    TestLocation::
      TestLocation(const StringType& file, int line)
      : _file(file),_line(line)
    {
    };

    TestLocation::
      TestLocation(const TestLocation& source)
    {
      _file=source._file;
      _line=source._line;
    };


    TestLocation&
      TestLocation::
      operator =(const TestLocation& rhs)
    { //spared self assignement check, because ist happens seldom
      //has no negativ effect in this case; so save the check cost
      _file=rhs._file;
      _line=rhs._line;
      return *this;
    };

    bool 
      TestLocation::
      operator ==(const TestLocation& rhs) const
    {
      //the sequence of comparison is ordered by the entropies of the attributes
      //so _line may differ most often.
      if (_line!=rhs._line) return false;
      if (_file!=rhs._file) return false;

      return true;
    };

    StringType
      TestLocation::
      getFile() const
    {
      return _file;
    };

    int
      TestLocation::
      getLine() const
    {
      return _line;
    };

    StringType
      TestLocation::
      toStr() const
    {
      OStringStream stream;
      stream << _file<<"("<<_line<<")";
      return stream.str();
    };

    std::ostream &
      operator<<(std::ostream &os, const TestLocation &location)
    {
      os << location.toStr();
      return os;
    };

}
