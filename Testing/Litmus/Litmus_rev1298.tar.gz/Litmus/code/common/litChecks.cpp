// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litChecks.h"
#include <string.h>

namespace lit {

void checkStringsEqual(TestResults& results, const TestLabel& label, char const* expected, char const* actual)
{
    results.onTestStart(label);
    if (strcmp(expected, actual))
    {
      OStringStream stream;
      stream << "Expected " << expected << " but was " << actual;
      results.onTestFailure(label, stream.str());
    }
    else
    {
      OStringStream stream;
      stream << expected << " equals " << actual;
      results.onTestSuccess(label, stream.str());
    }
}



void checkEqual(TestResults& results, const TestLabel& label, char const* expected, char const* actual)
{
    checkStringsEqual(results, label, expected, actual);
}

void checkEqual(TestResults& results, const TestLabel& label, char* expected, char* actual)
{
    checkStringsEqual(results, label, expected, actual);
}

void checkEqual(TestResults& results, const TestLabel& label, char* expected, char const* actual)
{
    checkStringsEqual(results, label, expected, actual);
}

void checkEqual(TestResults& results, const TestLabel& label, char const* expected, char* actual)
{
    checkStringsEqual(results, label, expected, actual);
}

void checkEqual(TestResults& results, const TestLabel& label, const StringType& expected, const StringType& actual)
{
  checkStringsEqual(results, label, expected.c_str(), actual.c_str());
}

void checkEqual(TestResults& results, const TestLabel& label, char const* expected, const StringType& actual)
{
  checkStringsEqual(results, label, expected, actual.c_str());
}

void checkEqual(TestResults& results, const TestLabel& label, const StringType& expected, char const* actual)
{
  checkStringsEqual(results, label, expected.c_str(), actual);
}




}
