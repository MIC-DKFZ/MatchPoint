// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_VALUE_RECORDER_H
#define __LIT_VALUE_RECORDER_H

#include <vector>

namespace lit {
    
    /*! @brief Helper class for recording arbitrary sequences of values
     * ValueRecorder can be used to record a sequence of values within a test
     * and check the recording for content and value sequence. On typical task
     * is testing of function calls (e.g. for abstract classes implemented
     * regarding the NVI idiom). Every call is recorded as an item. When the
     * tests is finished you can check if the calls where executed (count, sequence)
     * @ingroup Testing Helper*/
    template <typename TRecordValue>
    class ValueRecorder
    {
    public:
      typedef TRecordValue RecordValueType;
      typedef std::vector<TRecordValue> RecordValueVectorType;
      typedef typename RecordValueVectorType::size_type RecordIndexType;
      typedef std::vector<RecordIndexType> RecordIndexVectorType;
      typedef typename RecordValueVectorType::size_type RecordCountType;

      const RecordValueVectorType& getRecordValues() const;
      RecordCountType getTotalRecordValueCount() const;

      RecordIndexVectorType getRecordValueSequence(const RecordValueType& value) const;

      RecordCountType getRecordValueCount(const RecordValueType& value) const;

      bool checkRecordValue(const RecordValueType& value) const;

      bool checkRecordValueAt(const RecordValueType& value, const RecordIndexType& index) const;

      void resetRecorder();

      void recordValue(RecordValueType value);
    
      ValueRecorder() {};
      virtual ~ValueRecorder() {};

    private:

      RecordValueVectorType _recordedValues;

      ValueRecorder(ValueRecorder&); //purposely not implemented
      void operator=(const ValueRecorder&); //purposely not implemented
    };

}

#ifndef Litmus_MANUAL_TPP
# include "litValueRecorder.tpp"
#endif

#endif
