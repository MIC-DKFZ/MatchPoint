// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTestResults.h"
#include "litTestReporter.h"

namespace lit {

    TestResults::
      TestResults(TestReporter* testReporter)
      : _pTestReporter(testReporter)
      , _totalTestCount(0)
      , _failureCount(0)
      , _successCount(0)
    {
    }

    void
      TestResults::
      reportSummary() const
    {
      if (_pTestReporter)
      {
        _pTestReporter->reportSummary(_totalTestCount,_failureCount,(double)(_latestTestStop - _firstTestStart) / CLOCKS_PER_SEC);
      }
    };

    void
      TestResults::
      onTestStart(const LabelType& label)
    {
      if (_totalTestCount==0)
      {
        _firstTestStart = clock();
      }

      ++_totalTestCount;
      if (_pTestReporter)
      {
        _pTestReporter->reportTestStart(label);
      }
    }

    void
      TestResults::
      onTestFailure(const LabelType& label, const StringType& failure)
    {
      ++_failureCount;

      if (_pTestReporter)
      {
        _pTestReporter->reportFailure(label, failure);
      }
      
      _latestTestStop = clock();

    }

    void
      TestResults::
      onTestSuccess(const LabelType& label, const StringType& success)
    {
      ++_successCount;

      if (_pTestReporter)
      {
        _pTestReporter->reportSuccess(label, success);
      }

      _latestTestStop = clock();
    }

    unsigned long
      TestResults::
    getTotalTestCount() const
    {
      return _totalTestCount;
    }

    unsigned long
		TestResults::
		getSuccessCount() const
    {
      return _successCount;
    }

    unsigned long 
		TestResults::
		getFailureCount() const
    {
      return _failureCount;
    }

    TestReporter*
 		TestResults::
    getReporter() const
    {

      return _pTestReporter;
    };

}
