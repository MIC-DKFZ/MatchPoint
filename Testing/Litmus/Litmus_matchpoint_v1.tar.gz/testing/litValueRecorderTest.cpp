// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litValueRecorder.h"
#include <iostream>

int main (int argc, char* argv[])
{
  typedef lit::ValueRecorder<char> TestRecorderType;
  TestRecorderType recorder;

  if (!recorder.getRecordValues().empty())
  {
    std::cout << "Error! ValueRecorder is not empty after construction." << std::endl;
    return EXIT_FAILURE;
  }

  if (recorder.getTotalRecordValueCount() != 0)
  {
    std::cout << "Error! ValueRecorder got wrong total value count. Expected: 0; Actual: " << recorder.getTotalRecordValueCount() << std::endl;
    return EXIT_FAILURE;
  }

  recorder.recordValue('h');
  if (recorder.getRecordValues()[0] != 'h')
  {
    std::cout << "Error! ValueRecorder internal vector got a wrong value. Expected: h; Actual: " << recorder.getRecordValues()[0] << std::endl;
    return EXIT_FAILURE;
  }

  recorder.recordValue('e');
  if (recorder.getRecordValues()[1] != 'e')
  {
    std::cout << "Error! ValueRecorder internal vector got a wrong value. Expected: e; Actual: " << recorder.getRecordValues()[0] << std::endl;
    return EXIT_FAILURE;
  }

  recorder.recordValue('l');
  recorder.recordValue('l');
  recorder.recordValue('o');
  recorder.recordValue('W');
  recorder.recordValue('o');
  recorder.recordValue('r');
  recorder.recordValue('l');
  recorder.recordValue('d');

  //test search for first element
  TestRecorderType::RecordIndexVectorType seq = recorder.getRecordValueSequence('h');
  if (seq.size()!=1)
  {
    std::cout << "Error! Record sequence size for 'h' is incorrect. Expected: 1; Actual: " << seq.size() << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[0]!=0)
  {
    std::cout << "Error! Record sequence index for 'h' is incorrect. Expected: 0; Actual: " << seq[0] << std::endl;
    return EXIT_FAILURE;
  }

  //test search for last element
  seq = recorder.getRecordValueSequence('d');
  if (seq.size()!=1)
  {
    std::cout << "Error! Record sequence size for 'd' is incorrect. Expected: 1; Actual: " << seq.size() << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[0]!=9)
  {
    std::cout << "Error! Record sequence index for 'd' is incorrect. Expected: 9; Actual: " << seq[0] << std::endl;
    return EXIT_FAILURE;
  }

  //test search for scattered element
  seq = recorder.getRecordValueSequence('l');
  if (seq.size()!=3)
  {
    std::cout << "Error! Record sequence size for 'l' is incorrect. Expected: 3; Actual: " << seq.size() << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[0]!=2)
  {
    std::cout << "Error! First record sequence index for 'l' is incorrect. Expected: 2; Actual: " << seq[0] << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[1]!=3)
  {
    std::cout << "Error! First record sequence index for 'l' is incorrect. Expected: 3; Actual: " << seq[1] << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[2]!=8)
  {
    std::cout << "Error! First record sequence index for 'l' is incorrect. Expected: 8; Actual: " << seq[2] << std::endl;
    return EXIT_FAILURE;
  }

  //test search for scattered element (2nd Test)
  seq = recorder.getRecordValueSequence('o');
  if (seq.size()!=2)
  {
    std::cout << "Error! Record sequence size for 'o' is incorrect. Expected: 2; Actual: " << seq.size() << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[0]!=4)
  {
    std::cout << "Error! First record sequence index for 'o' is incorrect. Expected: 4; Actual: " << seq[0] << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[1]!=6)
  {
    std::cout << "Error! First record sequence index for 'o' is incorrect. Expected: 6; Actual: " << seq[1] << std::endl;
    return EXIT_FAILURE;
  }

  //test search for single middle element
  seq = recorder.getRecordValueSequence('e');
  if (seq.size()!=1)
  {
    std::cout << "Error! Record sequence size for 'e' is incorrect. Expected: 1; Actual: " << seq.size() << std::endl;
    return EXIT_FAILURE;
  }
  if (seq[0]!=1)
  {
    std::cout << "Error! First record sequence index for 'e' is incorrect. Expected: 1; Actual: " << seq[0] << std::endl;
    return EXIT_FAILURE;
  }

  //test search for non existant element
  seq = recorder.getRecordValueSequence('X');
  if (seq.size()!=0)
  {
    std::cout << "Error! Record sequence size for 'X' is incorrect. Expected: 0; Actual: " << seq.size() << std::endl;
    return EXIT_FAILURE;
  }

  //test: getRecordValueCount

  if (recorder.getRecordValueCount('h')!=1)
  {
    std::cout << "Error! getRecordValueCount for 'h' is incorrect. Expected: 1; Actual: " << recorder.getRecordValueCount('h') << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.getRecordValueCount('d')!=1)
  {
    std::cout << "Error! getRecordValueCount for 'd' is incorrect. Expected: 1; Actual: " << recorder.getRecordValueCount('d') << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.getRecordValueCount('l')!=3)
  {
    std::cout << "Error! getRecordValueCount for 'l' is incorrect. Expected: 1; Actual: " << recorder.getRecordValueCount('l') << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.getRecordValueCount('o')!=2)
  {
    std::cout << "Error! getRecordValueCount for 'o' is incorrect. Expected: 1; Actual: " << recorder.getRecordValueCount('o') << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.getRecordValueCount('e')!=1)
  {
    std::cout << "Error! getRecordValueCount for 'e' is incorrect. Expected: 1; Actual: " << recorder.getRecordValueCount('e') << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.getRecordValueCount('X')!=0)
  {
    std::cout << "Error! getRecordValueCount for 'X' is incorrect. Expected: 0; Actual: " << recorder.getRecordValueCount('X') << std::endl;
    return EXIT_FAILURE;
  }

  //test: checkRecordValue
  if (!recorder.checkRecordValue('h'))
  {
    std::cout << "Error! checkRecordValue for 'h' is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (!recorder.checkRecordValue('d'))
  {
    std::cout << "Error! checkRecordValue for 'd' is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (!recorder.checkRecordValue('l'))
  {
    std::cout << "Error! checkRecordValue for 'l' is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (!recorder.checkRecordValue('o'))
  {
    std::cout << "Error! checkRecordValue for 'o' is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (!recorder.checkRecordValue('e'))
  {
    std::cout << "Error! checkRecordValue for 'e' is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.checkRecordValue('X'))
  {
    std::cout << "Error! checkRecordValue for 'X' is true. Expected: false" << std::endl;
    return EXIT_FAILURE;
  }

  //test: checkRecordValueAt
  if (!recorder.checkRecordValueAt('d',9))
  {
    std::cout << "Error! checkRecordValueAt for 'd' at 9 is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.checkRecordValueAt('d',1))
  {
    std::cout << "Error! checkRecordValueAt for 'd' at 1 is true. Expected: false" << std::endl;
    return EXIT_FAILURE;
  }
  if (!recorder.checkRecordValueAt('h',0))
  {
    std::cout << "Error! checkRecordValueAt for 'h' at 0 is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.checkRecordValueAt('h',7))
  {
    std::cout << "Error! checkRecordValueAt for 'h' at 7 is true. Expected: false" << std::endl;
    return EXIT_FAILURE;
  }
  if (!recorder.checkRecordValueAt('o',4))
  {
    std::cout << "Error! checkRecordValueAt for 'o' at 4 is false. Expected: true" << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.checkRecordValueAt('o',5))
  {
    std::cout << "Error! checkRecordValueAt for 'o' at 5 is true. Expected: false" << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.checkRecordValueAt('X',4)) //nonexistant value inside the record
  {
    std::cout << "Error! checkRecordValueAt for 'X' at 4 is true. Expected: false" << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.checkRecordValueAt('X',200)) //nonexistant value outside the record
  {
    std::cout << "Error! checkRecordValueAt for 'X' at 200 is true. Expected: false" << std::endl;
    return EXIT_FAILURE;
  }
  if (recorder.checkRecordValueAt('h',200)) //existant value outside the record
  {
    std::cout << "Error! checkRecordValueAt for 'h' at 200 is true. Expected: false" << std::endl;
    return EXIT_FAILURE;
  }

  recorder.resetRecorder();
  
  if (!recorder.getRecordValues().empty())
  {
    std::cout << "Error! ValueRecorder is not empty after reset." << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};
