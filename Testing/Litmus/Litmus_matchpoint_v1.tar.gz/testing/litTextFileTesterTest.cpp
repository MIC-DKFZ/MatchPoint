// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTextFileTester.h"
#include "litDefaultTestReporting.h"

#include <iostream>
#include <stdlib.h>

int main (int argc, char* argv[])
{  
  lit::TextFileTester tester;

  lit::StringType filePath1 = argv[1];
  lit::StringType filePath2 = argv[2];

  tester.setExpectedFile("a");
  tester.setActualFile("b");

  if (tester.getExpectedFile() != "a")
  {
    std::cout << "Error! setExpectedFile() or getExpectedFile() is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  if (tester.getActualFile() != "b")
  {
    std::cout << "Error! setActualFile() or getActualFile() is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  tester.setExpectedFile(filePath1);
  tester.setActualFile(filePath1);

  ::lit::TestResults& testResults = ::lit::getTestResults();
  ::lit::TestLocation testLocation("test.file",1);

  tester.check(testResults, testLocation);

  if (testResults.getSuccessCount()!=1)
  {
    std::cout << "Error! Equal files was not recognized as equal." << std::endl;
    return EXIT_FAILURE;
  }

  tester.setActualFile(filePath2);

  tester.check(testResults, testLocation);

  if (testResults.getFailureCount()!=1)
  {
    std::cout << "Error! Unequal files was not recognized as unequal." << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};
