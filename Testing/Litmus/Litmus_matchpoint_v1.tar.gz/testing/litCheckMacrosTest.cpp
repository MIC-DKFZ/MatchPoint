// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litCheckMacros.h"
#include "litTesterMock.h"

#include <iostream>

int main (int argc, char* argv[])
{
  PREPARE_DEFAULT_TEST_REPORTING;

  double a1[5];
  double a2[5];
  double a3[5];

  for (int i = 0; i<5; ++i)
  {
    a1[i] = i;
    a2[i] = i;
    a3[i] = i;
  }

  a3[2] = 2.2;

  /***********************************************
   * CHECK
   ***********************************************/
  std::cout << "CHECK(true): test should succeed:" << std::endl;
  CHECK(true);
  if ((testResults.getFailureCount()!=0)||(testResults.getSuccessCount()!=1))
  {
    std::cout << "Error! CHECK is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK(false): test should fail:" << std::endl;
  CHECK(false);
  if ((testResults.getFailureCount()!=1)||(testResults.getSuccessCount()!=1))
  {
    std::cout << "Error! CHECK is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }


  /***********************************************
   * CHECK_EQUAL
   ***********************************************/
  std::cout << "CHECK_EQUAL(0, 0): test should succeed:" << std::endl;
  CHECK_EQUAL(0, 0);
  if ((testResults.getFailureCount()!=1)||(testResults.getSuccessCount()!=2))
  {
    std::cout << "Error! CHECK_EQUAL is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_EQUAL(0, 1): test should fail:" << std::endl;
  CHECK_EQUAL(0, 1);
  if ((testResults.getFailureCount()!=2)||(testResults.getSuccessCount()!=2))
  {
    std::cout << "Error! CHECK_EQUAL is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_CLOSE
   ***********************************************/
  std::cout << "CHECK_CLOSE(0, 0, 0): test should succeed:" << std::endl;
  CHECK_CLOSE(0, 0, 0);
  if ((testResults.getFailureCount()!=2)||(testResults.getSuccessCount()!=3))
  {
    std::cout << "Error! CHECK_CLOSE is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_CLOSE(0, 1.0, 0): test should fail:" << std::endl;
  CHECK_CLOSE(0.0, 1.0, 0.0);
  if ((testResults.getFailureCount()!=3)||(testResults.getSuccessCount()!=3))
  {
    std::cout << "Error! CHECK_CLOSE is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_CLOSE(0, 0.4, 0.5): test should succeed:" << std::endl;
  CHECK_CLOSE(0.0, 0.4, 0.5);
  if ((testResults.getFailureCount()!=3)||(testResults.getSuccessCount()!=4))
  {
    std::cout << "Error! CHECK_CLOSE is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_ARRAY_EQUAL
   ***********************************************/

  std::cout << "CHECK_ARRAY_EQUAL(a1, a2, 5): test should succeed:" << std::endl;
  CHECK_ARRAY_EQUAL(a1, a2, 5);
  if ((testResults.getFailureCount()!=3)||(testResults.getSuccessCount()!=5))
  {
    std::cout << "Error! CHECK_ARRAY_EQUAL is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_ARRAY_EQUAL(a1, a3, 5): test should fail:" << std::endl;
  CHECK_ARRAY_EQUAL(a1, a3, 5);
  if ((testResults.getFailureCount()!=4)||(testResults.getSuccessCount()!=5))
  {
    std::cout << "Error! CHECK_ARRAY_EQUAL is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_ARRAY_CLOSE
   ***********************************************/
  std::cout << "CHECK_ARRAY_CLOSE(a1, a2, 5, 0.0): test should succeed:" << std::endl;
  CHECK_ARRAY_CLOSE(a1, a2, 5, 0.0);
  if ((testResults.getFailureCount()!=4)||(testResults.getSuccessCount()!=6))
  {
    std::cout << "Error! CHECK_ARRAY_CLOSE is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_ARRAY_CLOSE(a1, a3, 5, 0.0): test should fail:" << std::endl;
  CHECK_ARRAY_CLOSE(a1, a3, 5, 0.0);
  if ((testResults.getFailureCount()!=5)||(testResults.getSuccessCount()!=6))
  {
    std::cout << "Error! CHECK_ARRAY_CLOSE is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_ARRAY_CLOSE(a1, a3, 5, 0.3): test should succeed:" << std::endl;
  CHECK_ARRAY_CLOSE(a1, a3, 5, 0.3);
  if ((testResults.getFailureCount()!=5)||(testResults.getSuccessCount()!=7))
  {
    std::cout << "Error! CHECK_ARRAY_CLOSE is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_THROW_EXPLICIT
   ***********************************************/
  std::cout << "CHECK_THROW_EXPLICIT(throw int(1), int): test should succeed:" << std::endl;
  CHECK_THROW_EXPLICIT(throw int(1), int);
  if ((testResults.getFailureCount()!=5)||(testResults.getSuccessCount()!=8))
  {
    std::cout << "Error! CHECK_THROW_EXPLICIT is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_THROW_EXPLICIT(throw char('a'), int): test should fail:" << std::endl;
  CHECK_THROW_EXPLICIT(throw char('a'), int);
  if ((testResults.getFailureCount()!=6)||(testResults.getSuccessCount()!=8))
  {
    std::cout << "Error! CHECK_THROW_EXPLICIT is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_THROW_EXPLICIT(int i = 0, int): test should fail:" << std::endl;
  CHECK_THROW_EXPLICIT(int i = 0, int);
  if ((testResults.getFailureCount()!=7)||(testResults.getSuccessCount()!=8))
  {
    std::cout << "Error! CHECK_THROW_EXPLICIT is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_THROW
   ***********************************************/
  std::cout << "CHECK_THROW(throw 32): test should succeed:" << std::endl;
  CHECK_THROW(throw 32);
  if ((testResults.getFailureCount()!=7)||(testResults.getSuccessCount()!=9))
  {
    std::cout << "Error! CHECK_THROW is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_THROW(int i = 0): test should fail:" << std::endl;
  CHECK_THROW(int i = 0);
  if ((testResults.getFailureCount()!=8)||(testResults.getSuccessCount()!=9))
  {
    std::cout << "Error! CHECK_THROW is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_NO_THROW_EXPLICIT
   ***********************************************/
  std::cout << "CHECK_NO_THROW_EXPLICIT(throw int(1), int): test should fail:" << std::endl;
  CHECK_NO_THROW_EXPLICIT(throw int(1), int);
  if ((testResults.getFailureCount()!=9)||(testResults.getSuccessCount()!=9))
  {
    std::cout << "Error! CHECK_NO_THROW_EXPLICIT is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_NO_THROW_EXPLICIT(throw char('a'), int): test should succeed:" << std::endl;
  CHECK_NO_THROW_EXPLICIT(throw char('a'), int);
  if ((testResults.getFailureCount()!=9)||(testResults.getSuccessCount()!=10))
  {
    std::cout << "Error! CHECK_NO_THROW_EXPLICIT is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_NO_THROW_EXPLICIT(int i = 0, int): test should succeed:" << std::endl;
  CHECK_NO_THROW_EXPLICIT(int i = 0, int);
  if ((testResults.getFailureCount()!=9)||(testResults.getSuccessCount()!=11))
  {
    std::cout << "Error! CHECK_NO_THROW_EXPLICIT is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_NO_THROW
   ***********************************************/
  std::cout << "CHECK_NO_THROW(throw 32): test should fail:" << std::endl;
  CHECK_NO_THROW(throw 32);
  if ((testResults.getFailureCount()!=10)||(testResults.getSuccessCount()!=11))
  {
    std::cout << "Error! CHECK_NO_THROW is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "CHECK_NO_THROW(int i = 0): test should succeed:" << std::endl;
  CHECK_NO_THROW(int i = 0);
  if ((testResults.getFailureCount()!=10)||(testResults.getSuccessCount()!=12))
  {
    std::cout << "Error! CHECK_NO_THROW is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  /***********************************************
   * CHECK_TESTER
   ***********************************************/
  lit::testing::TesterMock mock;

  std::cout << "CHECK_TESTER(mock): test should fail:" << std::endl;
  CHECK_TESTER(mock);
  if ((mock._handleFailureCalls!=1)||(mock._handleSuccessCalls!=0))
  {
    std::cout << "Error! CHECK_TESTER is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }

  mock._checkSuccess = true;

  std::cout << "CHECK_TESTER(mock): test should succeed:" << std::endl;
  CHECK_TESTER(mock);
  if ((mock._handleFailureCalls!=1)||(mock._handleSuccessCalls!=1))
  {
    std::cout << "Error! CHECK_TESTER is incorrect.(Line:"<<__LINE__ <<")" << std::endl;
    return EXIT_FAILURE;
  }


  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};