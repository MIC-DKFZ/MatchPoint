// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTesterMock.h"

#include <iostream>
#include <stdlib.h>

int main (int argc, char* argv[])
{
  lit::testing::TesterMock mock;

  lit::TestResults results;
  lit::TestLocation location("Location",42);

  if (mock.getTestName()!="Mock")
  {
    std::cout << "Error! Test name incorrect." << std::endl;
    return EXIT_FAILURE;
  }

  if (mock.getInvertCheck())
  {
    std::cout << "Error! Invert check incorrect initialized." << std::endl;
    return EXIT_FAILURE;
  }

  mock.setInvertCheck(true);
  if (!mock.getInvertCheck())
  {
    std::cout << "Error! setInvertCheck incorrect." << std::endl;
    return EXIT_FAILURE;
  }

  mock.setInvertCheck(false);
  if (mock.getInvertCheck())
  {
    std::cout << "Error! setInvertCheck incorrect." << std::endl;
    return EXIT_FAILURE;
  }

  mock.invertCheckOn();
  if (!mock.getInvertCheck())
  {
    std::cout << "Error! invertCheckOn incorrect." << std::endl;
    return EXIT_FAILURE;
  }

  mock.invertCheckOff();
  if (mock.getInvertCheck())
  {
    std::cout << "Error! invertCheckOff incorrect." << std::endl;
    return EXIT_FAILURE;
  }

  if ((mock._handleSuccessCalls!=0)||(mock._handleFailureCalls!=0))
  {
    std::cout << "Error! Tester mock's call counts are not initialized." << std::endl;
    return EXIT_FAILURE;
  }

  mock.check(results,location);

  if ((mock._handleFailureCalls!=1)||(mock._handleSuccessCalls!=0))
  {
    std::cout << "Error! Tester base does not propagate correctly.(Line:"<<__LINE__ << std::endl;
    return EXIT_FAILURE;
  }

  mock.invertCheckOn();
  mock.check(results,location);

  if ((mock._handleFailureCalls!=1)||(mock._handleSuccessCalls!=1))
  {
    std::cout << "Error! Tester base does not propagate correctly.(Line:"<<__LINE__ << std::endl;
    return EXIT_FAILURE;
  }

  mock.invertCheckOff();
  mock._checkSuccess = true;
  mock.check(results,location);

  if ((mock._handleFailureCalls!=1)||(mock._handleSuccessCalls!=2))
  {
    std::cout << "Error! Tester base does not propagate correctly.(Line:"<<__LINE__ << std::endl;
    return EXIT_FAILURE;
  }

  mock.invertCheckOn();
  mock.check(results,location);

  if ((mock._handleFailureCalls!=2)||(mock._handleSuccessCalls!=2))
  {
    std::cout << "Error! Tester base does not propagate correctly.(Line:"<<__LINE__ << std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};
