// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTestLabel.h"
#include <iostream>
#include <stdlib.h>

int main (int argc, char* argv[])
{
  lit::TestLabel label1("label1","test.cpp",42);

  if ((label1.getName() != "label1") || (label1.getFile() != "test.cpp") || (label1.getLine()!=42))
  {
    std::cout << "Error! Constructor label1(\"label1\",\"test.cpp\",42) generate illegal lable: " << label1 << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLocation location("test.cpp",42);
  lit::TestLabel label2("label2",location);

  if ((label2.getName() != "label2") || (label2.getFile() != "test.cpp") || (label2.getLine()!=42))
  {
    std::cout << "Error! Constructor label2(\"label2\",location) generates illegal lable: " << label2 << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLabel label3("test.cpp",43);

  if ((label3.getName() != "unnamed test") || (label3.getFile() != "test.cpp") || (label3.getLine()!=43))
  {
    std::cout << "Error! Constructor label3(\"test.cpp\",43) generates illegal lable: " << label3 << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLabel label4(location);

  if ((label4.getName() != "unnamed test") || (label4.getFile() != "test.cpp") || (label4.getLine()!=42))
  {
    std::cout << "Error! Constructor label4(location) generates illegal lable: " << label4 << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLabel label5(label2);
  if ((label5.getName() != "label2") || (label5.getFile() != "test.cpp") || (label5.getLine()!=42))
  {
    std::cout << "Error! Constructor label5(label2) generates illegal lable: " << label5 << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLabel label6 = label1;
  if ((label6.getName() != "label1") || (label6.getFile() != "test.cpp") || (label6.getLine()!=42))
  {
    std::cout << "Error! assignment operator is incorrect" << std::endl;
    return EXIT_FAILURE;
  }

  if (!(label1 == label6))
  {
    std::cout << "Error! Comparison of labels is incorrect (label1 == lable6 -> false)" << std::endl;
    return EXIT_FAILURE;
  }

  if (label1 == label2)
  {
    std::cout << "Error! Comparison of labels is incorrect (label1 == lable2 -> true)" << std::endl;
    return EXIT_FAILURE;
  }

  if (label3 == label4)
  {
    std::cout << "Error! Comparison of labels is incorrect (label3 == lable4 -> true)" << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLabel label7("test2.cpp",43);

  if (label3 == label7)
  {
    std::cout << "Error! Comparison of labels is incorrect (label3 == lable7 -> true)" << std::endl;
    return EXIT_FAILURE;
  }

  if (label1.toStr() != "test.cpp(42) : label1")
  {
    std::cout << "Error! toStr() is not correct." << std::endl;
    return EXIT_FAILURE;
  }

  lit::TestLabel::setDefaultName("DefTest");

  lit::TestLabel label8(location);

  if (label8.getName() != "DefTest")
  {
    std::cout << "Error! setDefaultName or constructor label8(location) is not correct"<< std::endl;
    return EXIT_FAILURE;
  }

  std::cout << "Test: success." << std::endl;
  return EXIT_SUCCESS;
};
