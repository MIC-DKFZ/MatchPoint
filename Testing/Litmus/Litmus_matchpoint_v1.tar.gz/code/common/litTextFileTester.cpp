// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#include "litTextFileTester.h"

#include <assert.h>
#include <fstream>
#include <stdexcept>

namespace lit 
{

  void
    TextFileTester::
    setExpectedFile(const StringType& filePath)
  {
    _expectedFilePath = filePath;
  };

  void
    TextFileTester::
    setActualFile(const StringType& filePath)
  {
    _actualFilePath = filePath;
  };

  const StringType&
    TextFileTester::
    getExpectedFile() const
  {
    return _expectedFilePath;
  };

  const StringType&
    TextFileTester::
    getActualFile() const
  {
    return _actualFilePath;
  };

  StringType
    TextFileTester::
    getTestDescription(void) const
  {
    return "Checks if actual text file content equals expected text file content";
  };

  StringType
    TextFileTester::
    getTestName(void) const
  {
    OStringStream stream;
    stream << "Check equal: actual text file content == expected text file content)";

    return stream.str();
  };

  TextFileTester::
    TextFileTester() : _expectedFilePath(""), _actualFilePath("")
  {
  };

  TextFileTester::
    ~TextFileTester()
  {
  };

  bool
    TextFileTester::
    doCheck(void) const
  {
    bool filesEqual = false;

    std::ifstream expectedFile;
    std::ifstream actualFile;

    std::ios_base::openmode iOpenFlag = std::ios_base::in;

    expectedFile.open(_expectedFilePath.c_str(), iOpenFlag );
    actualFile.open(_actualFilePath.c_str(), iOpenFlag );

    if (!expectedFile.is_open()) throw std::runtime_error("Cannot open expected file");
    if (!actualFile.is_open()) throw std::runtime_error("Cannot open actual file");

    StringType expectedData;
    StringType actualData;

    // get length of files:
    expectedFile.seekg (0, std::ios::end);
    std::streamsize expectedFilesize = expectedFile.tellg();
    expectedFile.seekg (0, std::ios::beg);

    actualFile.seekg (0, std::ios::end);
    std::streamsize actualFilesize = actualFile.tellg();
    actualFile.seekg (0, std::ios::beg);

    // allocate memory:
    char *expectedBuffer = new char [expectedFilesize];
    char *actualBuffer = new char [actualFilesize];

    // read data as a block:
    try
    {
      expectedFile.read(expectedBuffer,expectedFilesize);
      actualFile.read(actualBuffer,actualFilesize);

      std::streamsize gsize = expectedFile.gcount();
      expectedData.insert(0,expectedBuffer,gsize);

      gsize = expectedFile.gcount();
      actualData.insert(0,actualBuffer,gsize);
    }
    catch(...)
    {
    }

    delete[] actualBuffer;
    delete[] expectedBuffer;
    expectedFile.close();
    actualFile.close();

    filesEqual = expectedData == actualData;
    return filesEqual;
  };

  void
    TextFileTester::
    handleSuccess(void) const
  {
    OStringStream stream;
    stream << "Content of actual file ("<<_actualFilePath <<") equals content of expected file ("<<_expectedFilePath<<")";

    _pResults->onTestSuccess(getCurrentTestLabel(), stream.str());
  };

  void
    TextFileTester::
    handleFailure(void) const
  {
    OStringStream stream;
    stream << "Content of actual file ("<<_actualFilePath <<") doesn't equal content of expected file ("<<_expectedFilePath<<")";
    _pResults->onTestFailure(getCurrentTestLabel(), stream.str());
  };

}
