// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4432 $ (last changed revision)
// @date    $Date: 2013-01-22 14:30:04 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
//
// This file is used to create TestDriver executables
// These executables are able to register a function pointer to a string name
// in a lookup table.   By including this file, it creates a main function
// that calls RegisterTests() then looks up the function pointer for the test
// specified on the command line.
*/


#include "litMultiTestsMain.h"
#include "litDefaultTestReporting.h"
#include "litString.h"
#include <map>
#include <iostream>
#include <string.h>

#ifdef LIT_ITK_SUPPORT_ENABLED
#include "itkMultiThreaderBase.h"
#endif

namespace lit
{
  int LitmusITK_EXPORT multiTestsMainWithITKThreads(int ac, char* av[] )
  {

#ifdef LIT_ITK_SUPPORT_ENABLED

    int tempAC = ac;
    char** tempAV = av;

    while (tempAC>1)
    {
      if (strcmp(tempAV[1], "--with-threads") == 0)
      {
        int numThreads = atoi(tempAV[2]);
        itk::MultiThreaderBase::SetGlobalDefaultNumberOfThreads(numThreads);
        ++tempAV;
        tempAC -= 1;
      }
      else if (strcmp(tempAV[1], "--without-threads") == 0)
      {
        itk::MultiThreaderBase::SetGlobalDefaultNumberOfThreads(1);
      }

      ++tempAV;
      tempAC -= 1;
    }

#endif

    return multiTestsMain(ac,av);

  }


} //namespace lit
