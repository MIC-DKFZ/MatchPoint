// -----------------------------------------------------------------------
// Litmus - DKFZ SIDT unit testing library
//
// Copyright (c) German Cancer Research Center (DKFZ),
// Software development for Integrated Diagnostic and Therapy (SIDT).
// ALL RIGHTS RESERVED.
// See litmusCopyright.txt or
// http://www.dkfz.de/en/sidt/projects/litmus/copyright.html
//
// This software is distributed WITHOUT ANY WARRANTY; without even
// the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
// PURPOSE.  See the above copyright notices for more information.
//
//------------------------------------------------------------------------
/*!
// @file
// @version $Revision: 4433 $ (last changed revision)
// @date    $Date: 2013-01-22 14:38:20 +0100 (Di, 22 Jan 2013) $ (last change date)
// @author  $Author: floca $ (last changed by)
*/


#ifndef __LIT_TRANSFORM_FIELD_TESTER_H
#define __LIT_TRANSFORM_FIELD_TESTER_H

#include "litTesterBase.h"

namespace lit {
    
    /*! @brief Tester that compares a vector field and a transform model
     * @ingroup Tester*/
    template<class TField, class TTransform>
    class TransformFieldTester: public TesterBase
    {
    public:
      typedef TransformFieldTester<TField,TTransform> Self;
      typedef TesterBase Superclass;
      typedef TField FieldType;
      typedef typename FieldType::ConstPointer FieldConstPointer;
      typedef typename FieldType::RegionType TestRegionType;
      typedef TTransform TransformType;
      typedef typename TransformType::Pointer TransformPointer;
      typedef typename TransformType::ConstPointer TransformConstPointer;

      virtual StringType getTestDescription(void) const;
      virtual StringType getTestName(void) const;

      void setReferenceTransform(const TransformType* pTransform);
      void setActualField(const FieldType* pField);
      void setCheckThreshold(double checkThreshold);
      void setTestRegion(const TestRegionType& testRegion);

      const TransformType* getReferenceTransform() const;
      const FieldType* getActualField() const;
      double getCheckThreshold() const;
      const TestRegionType& getTestRegion() const;

      TransformFieldTester();
      virtual ~TransformFieldTester();

    protected:
      TransformConstPointer _spReferenceTransform;
      FieldConstPointer _spActualField;
      TestRegionType _testRegion;
      bool _useTestRegion;

      double _checkThreshold;
      mutable unsigned long _errorPixelCount;
      mutable double _maxError;
      mutable typename FieldType::IndexType _maxErrorIndex;

      /*! performes the test and checks the results.
       * @result Indicates if the test was successfull (true) or if it failed (false)
       */
      virtual bool doCheck(void) const;

      /*! Function will be called be check() if test was succesfull.
       * Implement to realize special tester behaviour.
       */
      virtual void handleSuccess(void) const;

      /*! Function will be called be check() if test was a failure.
       * Implement to realize special tester behaviour.
       */
      virtual void handleFailure(void) const;

    private:
      TransformFieldTester(Self& source); //purposely not implemented
      void operator=(const Self&); //purposely not implemented
    };

}

#ifndef Litmus_MANUAL_TPP
# include "litTransformFieldTester.tpp"
#endif

#endif
